package com.example.gpayments.configure;

public class CardRangeHeaderConfiguration {
}
