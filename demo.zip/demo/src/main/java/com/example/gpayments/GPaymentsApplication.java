package com.example.gpayments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GPaymentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GPaymentsApplication.class, args);
	}

}
